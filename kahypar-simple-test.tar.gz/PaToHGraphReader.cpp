
#include <stdlib.h>
#include <string>
#include <fstream>
#include <vector>
#include <iostream>
#include <assert.h>
#include <string.h>

#include "PaToHGraphReader.h"

void SplitStringToWords(const std::string& str, std::vector<std::string>& tokens, const std::string& delimiters) {
    // skip delimiters at beginning
    std::string::size_type lastPos = str.find_first_not_of(delimiters, 0);
    // find first non-delimiter
    std::string::size_type pos = str.find_first_of(delimiters, lastPos);

    while (std::string::npos != pos || std::string::npos != lastPos) {
        // found a token, add it to the vector
        tokens.push_back(str.substr(lastPos, pos - lastPos));
        // skip the delimjiters
        lastPos = str.find_first_not_of(delimiters, pos);
        // find next non-delimiter
        pos = str.find_first_of(delimiters, lastPos);
    }
}

void TrimLeft(std::string& str) {
    std::string::size_type pos = str.find_first_not_of(" \t");
    if (std::string::npos != pos) {
        str = str.substr(pos);
    }
}

void TrimComment(std::string& str) {
    std::string::size_type pos = str.find_first_of("%");
    if (std::string::npos != pos) {
        str = str.substr(0, pos);
    }
}

void TrimRight(std::string& str) {
    std::string::size_type pos = str.find_last_not_of(" \t");
    str = str.substr(0, pos + 1);
}

void Trim(std::string& str) {
    TrimLeft(str);
    TrimRight(str);
    TrimComment(str);
}

int ReadOneLine(std::ifstream& file, std::string& oneLine) {
    while(1) {
        getline(file, oneLine);
        if (file.eof() && file.fail()) {
            return 1;
        }

        if (oneLine.size() == 0) { // for dangling net, there is no inst connected
            return 0;
        }

        Trim(oneLine);
        if (oneLine.size() == 0) {
            continue;
        } else if (oneLine[0] == '%') {
            continue;
        } else {
            return 0;
        }
    }
}

void ReadHypergraph(const std::string& filename, int *_c, int *_n,
        int **cwghts, /*int **nwghts,*/ int **xpins, int **pins) {
    std::ifstream file;
    file.open(filename);
    if (file.fail()) {
        std::cout<<"## Read hypergraph error: open graph file failed."<<std::endl;
        exit(1);
    }

    // read head line
    std::string headLine = "";
    if (ReadOneLine(file, headLine) > 0) {
        std::cout<<"## Read hypergraph error: no any valid lines."<<std::endl;
    }
    std::vector<std::string> strVec;
    SplitStringToWords(headLine, strVec);
    if (strVec.size() < 4) {
        std::cout<<"## Read hypergraph error: Cannot read numbering, #cells, #nets, #pins."<<std::endl;
    }
    *_c = atoi(strVec[1].c_str());
    *_n = atoi(strVec[2].c_str());
    int n_pins = atoi(strVec[3].c_str());
    *xpins = new int[*_n + 1];
    *pins = new int[n_pins];
    *cwghts = new int[*_c];
    if (strVec.size() > 4) {
        assert(atoi(strVec[4].c_str()) == 1);
    }
    if (strVec.size() > 5) {
        assert(atoi(strVec[5].c_str()) == 1);
    }


    // read nets info
    int nid = 1;
    int pid = 0;
    std::string oneLine;
    *xpins[0] = 0;
    while((nid < (*_n) + 1) && (0 == ReadOneLine(file, oneLine))) {
        std::vector<std::string> strVec;
        SplitStringToWords(oneLine, strVec);
        for(auto str : strVec) {
            if (pid < n_pins) {
                (*pins)[pid] = atoi(str.c_str());
            }
            pid++;
        }
        (*xpins)[nid] = pid;
        nid++;
    }
    if (pid != n_pins) {
        std::cout<<"## Read hypergraph error: Something wrong with the pins from input file "<<n_pins<<" "<<pid<<std::endl;
        exit(1);
    }

    // read cell weights
    int cid = 0;
    while(0 == ReadOneLine(file, oneLine)) {
        std::vector<std::string> strVec;
        SplitStringToWords(oneLine, strVec);
        for(auto str : strVec) {
            if (cid < (*_c)) {
                (*cwghts)[cid] = atoi(str.c_str());
            }
            cid++;
        }
    }
    if (cid != (*_c)) {
        std::cout<<"## Read hypergraph error: Something wrong with the cells from input file "<<*_c<<" "<<cid<<std::endl;
        exit(1);
    }

    file.close();
    std::cout<<"***********************************************************************"<<std::endl;
    std::cout<<"Hypergraph: #Cells : "<< *_c << "  #Nets : " << *_n << "  #pins : " << n_pins << std::endl;
    std::cout<<"***********************************************************************"<<std::endl;
}

void WritePartitionResult(const std::string& inFileName, int npart, int _c, int* partResult, const char* toolname) {
    std::cout<<"## Info: Writing partition result ... "<<std::endl;
    std::string outFileName = inFileName + "."+ toolname + ".part." + std::to_string(npart);
    std::ofstream outFile;
    outFile.open(outFileName);
    if (outFile.fail()) {
        std::cout<<"## Error: Write result file failed."<<std::endl;
        exit(1);
    }
    int count = 0;
    for(int i = 0; i < _c; ++i) {
        if (count == 100) {
            count = 0;
            outFile<<"\n";
        }
        outFile<<partResult[i]<<" ";
        count++;
    }
    outFile<<"\n";
    outFile.close();
}
