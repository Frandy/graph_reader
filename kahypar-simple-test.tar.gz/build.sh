g++ testKaHyPar.cpp PaToHGraphReader.cpp -I. -I../include -L../build/lib/ -lkahypar
