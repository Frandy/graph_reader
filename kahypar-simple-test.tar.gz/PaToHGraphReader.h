
#ifndef READ_GRAPH_HPP
#define READ_GRAPH_HPP

#include <string>
#include <fstream>
#include <vector>
#include <iostream>
#include <assert.h>
#include <string.h>


void SplitStringToWords(const std::string& str, std::vector<std::string>& tokens, const std::string& delimiters = " \t");
void TrimLeft(std::string& str); 
void TrimComment(std::string& str);
void TrimRight(std::string& str); 
void Trim(std::string& str);
int ReadOneLine(std::ifstream& file, std::string& oneLine); 
void ReadHypergraph(const std::string& filename, int *_c, int *_n,
        int **cwghts, /*int **nwghts,*/ int **xpins, int **pins); 
void WritePartitionResult(const std::string& inFileName, int npart, int _c, int* partResult, const char* toolname); 

#endif