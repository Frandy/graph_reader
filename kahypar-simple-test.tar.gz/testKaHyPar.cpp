

#include <memory>
#include <vector>
#include <iostream>

#include <libkahypar.h>

#include "PaToHGraphReader.h"

void PartitionHypergraph(const std::string& inFileName, int npart, int configChoice = 0) {
    int _c, _n;
    int* cwghts = NULL;
    int* nwghts = NULL;
    int* xpins = NULL;
    int* pins = NULL;
    std::cout<<"## Info: Reading hypergraph " << inFileName << " ... "<<std::endl;
    ReadHypergraph(inFileName, &_c, &_n, &cwghts, /*&nwghts,*/ &xpins, &pins);

    kahypar_context_t* context = kahypar_context_new();
    //  kahypar_configure_context_from_file(context, "../config/km1_direct_kway_gecco18.ini");
    std::string config_name[] = {"cut_rb_alenex16.ini",  "km1_direct_kway_alenex17.ini",  "km1_direct_kway_gecco18.ini",  "km1_direct_kway_sea17.ini",  "km1_direct_kway_sea18.ini"};
    std::string config_file_name = "";
    config_file_name = config_file_name + "../config/" + config_name[configChoice];
    config_file_name = "cut_direct_kway_alenex17.ini";
    kahypar_configure_context_from_file(context, config_file_name.c_str());

    const kahypar_hypernode_id_t num_vertices = _c;
    const kahypar_hyperedge_id_t num_hyperedges = _n;

    std::unique_ptr<kahypar_hyperedge_weight_t[]> hyperedge_weights = nullptr; // std::make_unique<kahypar_hyperedge_weight_t[]>(num_hyperedges);
    std::unique_ptr<kahypar_hypernode_weight_t[]> vertex_weights = std::make_unique<kahypar_hypernode_weight_t[]>(num_vertices);
    for(int i = 0; i < num_vertices; ++i)
        vertex_weights[i] = cwghts[i];

    std::unique_ptr<size_t[]> hyperedge_indices = std::make_unique<size_t[]>(num_hyperedges+1);
    for(int i = 0; i < num_hyperedges+1; ++i)
        hyperedge_indices[i] = xpins[i];

    int n_pins = xpins[_n];
    std::unique_ptr<kahypar_hyperedge_id_t[]> hyperedges = std::make_unique<kahypar_hyperedge_id_t[]>(n_pins);
    for(int i = 0; i < n_pins; ++i)
        hyperedges[i] = pins[i];

    const double imbalance = 0.03;
    const kahypar_partition_id_t k = npart;

    kahypar_hyperedge_weight_t objective = 0;
    std::vector<kahypar_partition_id_t> partition(num_vertices, -1);
    std::cout<<"## Info: Partition hypergraph with KaHyPar "<<std::endl;

    kahypar_partition(num_vertices, num_hyperedges,
            imbalance, k,
            vertex_weights.get(),  nullptr,
            hyperedge_indices.get(), hyperedges.get(),
            &objective, context, partition.data());

    kahypar_context_free(context);
    
    std::cout << "## Info: objective: " << objective << std::endl;

    int* partResult = new int[_c];
    for(int i=0; i < _c; ++i)
        partResult[i] = partition[i];

    WritePartitionResult(inFileName, npart, _c, partResult, "KaHyPar");

    delete [] cwghts;
    //free(nwghts);
    delete [] xpins;
    delete [] pins;
}



int main(int argc, char* argv[]) {
    std::cout << "Partition With KaHypar" << std::endl;
    std::string inFileName = argv[1];

    int npart = atoi(argv[2]);
    //int i = 1;
    //for(i = 0; i < 2; ++i)
    PartitionHypergraph(inFileName, npart);
    std::cout << "done." << std::endl;
    return 0;
}
